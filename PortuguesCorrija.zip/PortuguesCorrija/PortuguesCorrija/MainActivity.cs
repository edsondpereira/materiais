﻿using Android.App;
using Android.OS;
using Android.Runtime;
using Android.Widget;
using AndroidX.AppCompat.App;
using System;
using AlertDialog = AndroidX.AppCompat.App.AlertDialog;

namespace PortuguesCorrija
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        TextView txtPalavra, txtLetra1, txtLetra2;
        Button btnIniciar, btnSobre, btnSair;
        TextView txtAcertos, txtErros;
        int acertos = 0, erros = 0;
        int qtdePalavras = 1;
        string palavraCorreta = "";
        string letraInformada = "";
        string acertou = "";
        ImageView imagem;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);

            txtPalavra = FindViewById<TextView>(Resource.Id.txtPalavra);
            txtLetra1 = FindViewById<TextView>(Resource.Id.txtLetra1);
            txtLetra2 = FindViewById<TextView>(Resource.Id.txtLetra2);
            txtAcertos = FindViewById<TextView>(Resource.Id.txtAcertosE);
            txtErros = FindViewById<TextView>(Resource.Id.txtErrosE);
            TextView horaInicial = FindViewById<TextView>(Resource.Id.txthoraInicialE);
            string strhoraInicial = DateTime.Now.ToString("HH:mm");
            horaInicial.Text = strhoraInicial;
            imagem = FindViewById<ImageView>(Resource.Id.imgRosto);

            btnSobre = FindViewById<Button>(Resource.Id.btnSobre);
            btnIniciar = FindViewById<Button>(Resource.Id.btnIniciar);
            btnSair = FindViewById<Button>(Resource.Id.btnSair);

            txtLetra1.Click += TxtLetra1_Click;

            txtLetra2.Click += TxtLetra2_Click;

            btnSobre.Click += BtnSobre_Click;

            btnSair.Click += BtnSair_Click;

            btnIniciar.Click += BtnIniciar_Click;
        }

        private void TxtLetra2_Click(object sender, EventArgs e)
        {
            string palavraDigitada = palavraCorreta;
            letraInformada = txtLetra2.Text; ;
            Letras();
        }

        private void BtnIniciar_Click(object sender, EventArgs e)
        {
            Sortear();
            btnIniciar.Enabled = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            TextView horaFinal = FindViewById<TextView>(Resource.Id.txthoraFinalE);
            string strhoraFinal = DateTime.Now.ToString("HH:mm");
            horaFinal.Text = strhoraFinal;
            ExibirMensagem("Fim de Aplicação", "Volte Sempre");
        }

        private void BtnSobre_Click(object sender, EventArgs e)
        {
            SetContentView(Resource.Layout.sobre);
        }

        private void TxtLetra1_Click(object sender, EventArgs e)
        {
            string palavraDigitada = palavraCorreta;
            letraInformada = txtLetra1.Text; ;
            Letras();
        }

        private void Letras()
        {
            acertou = "";
            if (palavraCorreta == "Lençol" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Lençol" && letraInformada != "ç")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Maçã" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Maçã" && letraInformada != "ç")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Assim" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Assim" && letraInformada != "m")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Também" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Também" && letraInformada != "m")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Exagero" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Exagero" && letraInformada != "x")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Atenção" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Atenção" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Você" && letraInformada == "c")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Você" && letraInformada != "c")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Proteção" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Proteção" && letraInformada != "ç")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Ambiente" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Ambiente" && letraInformada != "m")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Luz" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Luz" && letraInformada != "z")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Endereço" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Endereço" && letraInformada != "ç")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Penitência" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Penitência" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Acessório" && letraInformada == "ss")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Acessório" && letraInformada != "ss")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Contar" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Contar" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Perseverança" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Perseverança" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Impressora" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Impressora" && letraInformada != "m")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Lembrança" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Lembrança" && letraInformada != "m")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Próximo" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Próximo" && letraInformada != "x")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Corrigir" && letraInformada == "g")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Corrigir" && letraInformada != "g")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Berinjela" && letraInformada == "j")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Berinjela" && letraInformada != "j")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Sentado" && letraInformada == "S")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Sentado" && letraInformada != "S")
            {
                erros += 1;
                acertou = "S";
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Monitor" && letraInformada == "o")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Monitor" && letraInformada != "u")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Sentimento" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Sentimento" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Bruxa" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Bruxa" && letraInformada != "x")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Começo" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Começo" && letraInformada != "ç")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Pergunta" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Pergunta" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Ambulância" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Ambulância" && letraInformada != "m")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Rapidez" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Rapidez" && letraInformada != "z")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Pensar" && letraInformada == "s")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Pensar" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Poesia" && letraInformada == "s")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Poesia" && letraInformada != "s")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Textos" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Textos" && letraInformada != "x")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Paciência" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Paciência" && letraInformada != "n")
            {
                erros += 1;
                txtErros.Text = erros.ToString();
            }

            if (palavraCorreta == "Ônibus" && letraInformada == "s")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Ônibus" && letraInformada != "s")
            {
                erros += 1;
            }

            if (palavraCorreta == "Infância" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Infância" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Cemitério" && letraInformada == "C")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Cemitério" && letraInformada != "C")
            {
                erros += 1;
            }

            if (palavraCorreta == "Atriz" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Atriz" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Exercer" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Exercer" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Pobreza" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Pobreza" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Serra" && letraInformada == "S")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Serra" && letraInformada != "S")
            {
                erros += 1;
            }

            if (palavraCorreta == "Seringa" && letraInformada == "S")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Seringa" && letraInformada != "S")
            {
                erros += 1;
            }

            if (palavraCorreta == "Feliz" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Feliz" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Aproximar" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Aproximar" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Gorgeta" && letraInformada == "j")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Gorgeta" && letraInformada != "g")
            {
                erros += 1;
            }

            if (palavraCorreta == "Braço" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Braço" && letraInformada != "ç")
            {
                erros += 1;
            }

            if (palavraCorreta == "Paçoca" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Paçoca" && letraInformada != "ç")
            {
                erros += 1;
            }

            if (palavraCorreta == "Bagunça" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Bagunça" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Examinar" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Examinar" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Paz" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Paz" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Máximo" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Máximo" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Mexe" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Mexe" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Amizade" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Amizade" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Maço" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Maço" && letraInformada != "ç")
            {
                erros += 1;
            }

            if (palavraCorreta == "Bicho" && letraInformada == "ch")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Bicho" && letraInformada != "ch")
            {
                erros += 1;
            }

            if (palavraCorreta == "Azedo" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Azedo" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Pescoço" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Pescoço" && letraInformada != "ç")
            {
                erros += 1;
            }

            if (palavraCorreta == "Solução" && letraInformada == "ç")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Solução" && letraInformada != "ç")
            {
                erros += 1;
            }

            if (palavraCorreta == "Saldade" && letraInformada == "l")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Saldade" && letraInformada != "l")
            {
                erros += 1;
            }

            if (palavraCorreta == "Pintar" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Pintar" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Pimenta" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Pimenta" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Experiência" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Experiência" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Homem" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Homem" && letraInformada != "m")
            {
                erros += 1;
            }

            if (palavraCorreta == "Acerto" && letraInformada == "c")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Acerto" && letraInformada != "c")
            {
                erros += 1;
            }

            if (palavraCorreta == "Excluído" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Excluído" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Fortaleza" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Fortaleza" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Colegial" && letraInformada == "g")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Colegial" && letraInformada != "g")
            {
                erros += 1;
            }

            if (palavraCorreta == "Impulso" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Impulso" && letraInformada != "m")
            {
                erros += 1;
            }

            if (palavraCorreta == "Poente" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Poente" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Semáforo" && letraInformada == "S")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Semáforo" && letraInformada != "S")
            {
                erros += 1;
            }

            if (palavraCorreta == "Exame" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Exame" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Rizada" && letraInformada == "z")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Rizada" && letraInformada != "z")
            {
                erros += 1;
            }

            if (palavraCorreta == "Computador" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Computador" && letraInformada != "m")
            {
                erros += 1;
            }

            if (palavraCorreta == "Exercício" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Exercício" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Suspensão" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Suspensão" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Maldade" && letraInformada == "l")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Maldade" && letraInformada != "l")
            {
                erros += 1;
            }

            if (palavraCorreta == "Autor" && letraInformada == "u")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Autor" && letraInformada != "u")
            {
                erros += 1;
            }

            if (palavraCorreta == "Entendi" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Entendi" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Fósforo" && letraInformada == "s")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Fósforo" && letraInformada != "s")
            {
                erros += 1;
            }

            if (palavraCorreta == "Andar" && letraInformada == "n")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Andar" && letraInformada != "n")
            {
                erros += 1;
            }

            if (palavraCorreta == "Nuvem" && letraInformada == "m")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Nuvem" && letraInformada != "m")
            {
                erros += 1;
            }

            if (palavraCorreta == "Paixão" && letraInformada == "x")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Paixão" && letraInformada != "x")
            {
                erros += 1;
            }

            if (palavraCorreta == "Alfabeto" && letraInformada == "l")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Alfabeto" && letraInformada != "l")
            {
                erros += 1;
            }

            if (palavraCorreta == "Aparecer" && letraInformada == "c")
            {
                acertou = "S";
                acertos += 1;
                txtAcertos.Text = acertos.ToString();
            }
            else if (palavraCorreta == "Aparecer" && letraInformada != "c")
            {
                erros += 1;
            }

            if (acertou == "S")
                imagem.SetImageResource(Resource.Drawable.rosto_feliz);
            else
                imagem.SetImageResource(Resource.Drawable.rosto_triste);

            if (qtdePalavras > 80)
            {
                ExibirMensagem("Final", "Você chegou ao final!");
            }
            Sortear();
        }

        private void ExibirMensagem(string titulo, string texto)
        {
            AlertDialog.Builder mensagem = new AlertDialog.Builder(this);
            mensagem.SetMessage(titulo);
            mensagem.SetTitle(texto);
            mensagem.SetCancelable(false);
            mensagem.SetPositiveButton("Sair", delegate { Sair(); });
            mensagem.Show();
        }

        private void Sair()
        {
            AlertDialog.Builder mensagem = new AlertDialog.Builder(this);
            mensagem.Show();
            this.Finish();
        }

        private void Sortear()
        {
            if (qtdePalavras == 1)
            {
                txtPalavra.Text = "Len ol";
                txtLetra1.Text = "ç";
                txtLetra2.Text = "s";
                palavraCorreta = "Lençol";
            }

            if (qtdePalavras == 2)
            {
                txtPalavra.Text = "Ma ã";
                txtLetra1.Text = "s";
                txtLetra2.Text = "ç";
                palavraCorreta = "Maçã";
            }
            if (qtdePalavras == 3)
            {
                txtPalavra.Text = "Assi";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Assim";
            }
            if (qtdePalavras == 4)
            {
                txtPalavra.Text = "Ta bém";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Também";
            }
            if (qtdePalavras == 5)
            {
                txtPalavra.Text = "E agero";
                txtLetra1.Text = "z";
                txtLetra2.Text = "x";
                palavraCorreta = "Exagero";
            }
            if (qtdePalavras == 6)
            {
                txtPalavra.Text = "Ate ção";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Atenção";
            }
            if (qtdePalavras == 7)
            {
                txtPalavra.Text = "Vo ê";
                txtLetra1.Text = "ç";
                txtLetra2.Text = "c";
                palavraCorreta = "Você";
            }
            if (qtdePalavras == 8)
            {
                txtPalavra.Text = "Prote ão";
                txtLetra1.Text = "ç";
                txtLetra2.Text = "ss";
                palavraCorreta = "Proteção";
            }
            if (qtdePalavras == 9)
            {
                txtPalavra.Text = "A biente";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Ambiente";
            }
            if (qtdePalavras == 10)
            {
                txtPalavra.Text = "Lu";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Luz";
            }
            if (qtdePalavras == 11)
            {
                txtPalavra.Text = "Endere o";
                txtLetra1.Text = "s";
                txtLetra2.Text = "ç";
                palavraCorreta = "Endereço";
            }
            if (qtdePalavras == 12)
            {
                txtPalavra.Text = "Penitê cia";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Penitência";
            }
            if (qtdePalavras == 13)
            {
                txtPalavra.Text = "Ace ório";
                txtLetra1.Text = "ss";
                txtLetra2.Text = "ç";
                palavraCorreta = "Acessório";
            }
            if (qtdePalavras == 14)
            {
                txtPalavra.Text = "Co tar";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Contar";
            }
            if (qtdePalavras == 15)
            {
                txtPalavra.Text = "Persevera ça";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Perseverança";
            }
            if (qtdePalavras == 16)
            {
                txtPalavra.Text = "I pressora";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Impressora";
            }
            if (qtdePalavras == 17)
            {
                txtPalavra.Text = "Le brança";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Lembrança";
            }
            if (qtdePalavras == 18)
            {
                txtPalavra.Text = "Pró imo";
                txtLetra1.Text = "x";
                txtLetra2.Text = "ss";
                palavraCorreta = "Próximo";
            }
            if (qtdePalavras == 19)
            {
                txtPalavra.Text = "Corri ir";
                txtLetra1.Text = "j";
                txtLetra2.Text = "g";
                palavraCorreta = "Corrigir";
            }
            if (qtdePalavras == 20)
            {
                txtPalavra.Text = "Berin ela";
                txtLetra1.Text = "g";
                txtLetra2.Text = "j";
                palavraCorreta = "Berinjela";
            }
            if (qtdePalavras == 21)
            {
                txtPalavra.Text = " entado";
                txtLetra1.Text = "S";
                txtLetra2.Text = "C";
                palavraCorreta = "Sentado";
            }
            if (qtdePalavras == 22)
            {
                txtPalavra.Text = "M nitor";
                txtLetra1.Text = "u";
                txtLetra2.Text = "o";
                palavraCorreta = "Monitor";
            }
            if (qtdePalavras == 23)
            {
                txtPalavra.Text = "Sentime to";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Sentimento";
            }
            if (qtdePalavras == 24)
            {
                txtPalavra.Text = "Bru a";
                txtLetra1.Text = "ch";
                txtLetra2.Text = "x";
                palavraCorreta = "Bruxa";
            }
            if (qtdePalavras == 25)
            {
                txtPalavra.Text = "Come o";
                txtLetra1.Text = "ss";
                txtLetra2.Text = "ç";
                palavraCorreta = "Começo";
            }
            if (qtdePalavras == 26)
            {
                txtPalavra.Text = "Pergu ta";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Pergunta";
            }
            if (qtdePalavras == 27)
            {
                txtPalavra.Text = "A bulância";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Ambulância";
            }
            if (qtdePalavras == 28)
            {
                txtPalavra.Text = "Rapide ";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Rapidez";
            }
            if (qtdePalavras == 29)
            {
                txtPalavra.Text = "Pen ar";
                txtLetra1.Text = "s";
                txtLetra2.Text = "ç";
                palavraCorreta = "Pensar";
            }
            if (qtdePalavras == 30)
            {
                txtPalavra.Text = "Poe ia";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Poesia";
            }
            if (qtdePalavras == 31)
            {
                txtPalavra.Text = "Te tos";
                txtLetra1.Text = "x";
                txtLetra2.Text = "s";
                palavraCorreta = "Textos";
            }
            if (qtdePalavras == 32)
            {
                txtPalavra.Text = "Paciê cia";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Paciência";
            }
            if (qtdePalavras == 33)
            {
                txtPalavra.Text = "Ônibu ";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Ônibus";
            }
            if (qtdePalavras == 34)
            {
                txtPalavra.Text = "I fâcia";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Infância";
            }
            if (qtdePalavras == 35)
            {
                txtPalavra.Text = " emitério";
                txtLetra1.Text = "S";
                txtLetra2.Text = "C";
                palavraCorreta = "Cemitério";
            }
            if (qtdePalavras == 36)
            {
                txtPalavra.Text = "Atri ";
                txtLetra1.Text = "s";
                txtLetra2.Text = "z";
                palavraCorreta = "Atriz";
            }
            if (qtdePalavras == 37)
            {
                txtPalavra.Text = "E ercer";
                txtLetra1.Text = "z";
                txtLetra2.Text = "x";
                palavraCorreta = "Exercer";
            }
            if (qtdePalavras == 38)
            {
                txtPalavra.Text = "Pobre a";
                txtLetra1.Text = "x";
                txtLetra2.Text = "z";
                palavraCorreta = "Pobreza";
            }
            if (qtdePalavras == 39)
            {
                txtPalavra.Text = " erra";
                txtLetra1.Text = "S";
                txtLetra2.Text = "C";
                palavraCorreta = "Serra";
            }
            if (qtdePalavras == 40)
            {
                txtPalavra.Text = " eringa";
                txtLetra1.Text = "C";
                txtLetra2.Text = "S";
                palavraCorreta = "Seringa";
            }
            if (qtdePalavras == 41)
            {
                txtPalavra.Text = "Feli ";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Feliz";
            }
            if (qtdePalavras == 42)
            {
                txtPalavra.Text = "Apro imar";
                txtLetra1.Text = "ss";
                txtLetra2.Text = "x";
                palavraCorreta = "Aproximar";
            }
            if (qtdePalavras == 43)
            {
                txtPalavra.Text = "Gor eta";
                txtLetra1.Text = "g";
                txtLetra2.Text = "j";
                palavraCorreta = "Gorgeta";
            }
            if (qtdePalavras == 44)
            {
                txtPalavra.Text = "Bra o";
                txtLetra1.Text = "ss";
                txtLetra2.Text = "ç";
                palavraCorreta = "Braço";
            }
            if (qtdePalavras == 45)
            {
                txtPalavra.Text = "Pa oca";
                txtLetra1.Text = "ç";
                txtLetra2.Text = "ss";
                palavraCorreta = "Paçoca";
            }
            if (qtdePalavras == 46)
            {
                txtPalavra.Text = "Bagu ça";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Bagunça";
            }
            if (qtdePalavras == 47)
            {
                txtPalavra.Text = "E aminar";
                txtLetra1.Text = "z";
                txtLetra2.Text = "x";
                palavraCorreta = "Examinar";
            }
            if (qtdePalavras == 48)
            {
                txtPalavra.Text = "Pa ";
                txtLetra1.Text = "s";
                txtLetra2.Text = "z";
                palavraCorreta = "Paz";
            }
            if (qtdePalavras == 48)
            {
                txtPalavra.Text = "Má imo";
                txtLetra1.Text = "x";
                txtLetra2.Text = "ss";
                palavraCorreta = "Máximo";
            }
            if (qtdePalavras == 49)
            {
                txtPalavra.Text = "Me e";
                txtLetra1.Text = "ch";
                txtLetra2.Text = "x";
                palavraCorreta = "Mexe";
            }
            if (qtdePalavras == 50)
            {
                txtPalavra.Text = "Ami ade";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Amizade";
            }
            if (qtdePalavras == 51)
            {
                txtPalavra.Text = "Ma o";
                txtLetra1.Text = "ss";
                txtLetra2.Text = "ç";
                palavraCorreta = "Maço";
            }
            if (qtdePalavras == 52)
            {
                txtPalavra.Text = "Bi o";
                txtLetra1.Text = "x";
                txtLetra2.Text = "ch";
                palavraCorreta = "Bicho";
            }
            if (qtdePalavras == 53)
            {
                txtPalavra.Text = "A edo";
                txtLetra1.Text = "z";
                txtLetra2.Text = "x";
                palavraCorreta = "Azedo";
            }
            if (qtdePalavras == 54)
            {
                txtPalavra.Text = "Pesco o";
                txtLetra1.Text = "ç";
                txtLetra2.Text = "ss";
                palavraCorreta = "Pescoço";
            }
            if (qtdePalavras == 55)
            {
                txtPalavra.Text = "Solu ão";
                txtLetra1.Text = "ç";
                txtLetra2.Text = "ss";
                palavraCorreta = "Solução";
            }
            if (qtdePalavras == 56)
            {
                txtPalavra.Text = "Sa dade";
                txtLetra1.Text = "u";
                txtLetra2.Text = "l";
                palavraCorreta = "Saldade";
            }
            if (qtdePalavras == 57)
            {
                txtPalavra.Text = "Pi tar";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Pintar";
            }
            if (qtdePalavras == 58)
            {
                txtPalavra.Text = "Pime ta";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Pimenta";
            }
            if (qtdePalavras == 59)
            {
                txtPalavra.Text = "E periência";
                txtLetra1.Text = "s";
                txtLetra2.Text = "x";
                palavraCorreta = "Experiência";
            }
            if (qtdePalavras == 60)
            {
                txtPalavra.Text = "Home ";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Homem";
            }
            if (qtdePalavras == 61)
            {
                txtPalavra.Text = "A erto";
                txtLetra1.Text = "c";
                txtLetra2.Text = "ss";
                palavraCorreta = "Acerto";
            }
            if (qtdePalavras == 62)
            {
                txtPalavra.Text = "E cluído";
                txtLetra1.Text = "x";
                txtLetra2.Text = "x";
                palavraCorreta = "Excluído";
            }
            if (qtdePalavras == 63)
            {
                txtPalavra.Text = "Fortale a";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Fortaleza";
            }
            if (qtdePalavras == 63)
            {
                txtPalavra.Text = "Cole ial";
                txtLetra1.Text = "g";
                txtLetra2.Text = "j";
                palavraCorreta = "Colegial";
            }
            if (qtdePalavras == 64)
            {
                txtPalavra.Text = "I pulso";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Impulso";
            }
            if (qtdePalavras == 65)
            {
                txtPalavra.Text = "Poe te";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Poente";
            }
            if (qtdePalavras == 66)
            {
                txtPalavra.Text = " emáforo";
                txtLetra1.Text = "C";
                txtLetra2.Text = "S";
                palavraCorreta = "Semáforo";
            }
            if (qtdePalavras == 67)
            {
                txtPalavra.Text = "E ame";
                txtLetra1.Text = "z";
                txtLetra2.Text = "x";
                palavraCorreta = "Exame";
            }
            if (qtdePalavras == 68)
            {
                txtPalavra.Text = "Ri ada";
                txtLetra1.Text = "z";
                txtLetra2.Text = "s";
                palavraCorreta = "Rizada";
            }
            if (qtdePalavras == 69)
            {
                txtPalavra.Text = "Co putador";
                txtLetra1.Text = "m";
                txtLetra2.Text = "n";
                palavraCorreta = "Computador";
            }
            if (qtdePalavras == 70)
            {
                txtPalavra.Text = "E ercício";
                txtLetra1.Text = "x";
                txtLetra2.Text = "z";
                palavraCorreta = "Exercício";
            }
            if (qtdePalavras == 71)
            {
                txtPalavra.Text = "Suspe são";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Suspensão";
            }
            if (qtdePalavras == 72)
            {
                txtPalavra.Text = "Ma dade";
                txtLetra1.Text = "u";
                txtLetra2.Text = "l";
                palavraCorreta = "Maldade";
            }
            if (qtdePalavras == 73)
            {
                txtPalavra.Text = "A tor";
                txtLetra1.Text = "u";
                txtLetra2.Text = "l";
                palavraCorreta = "Autor";
            }
            if (qtdePalavras == 74)
            {
                txtPalavra.Text = "E tendi";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Entendi";
            }
            if (qtdePalavras == 75)
            {
                txtPalavra.Text = "Fó foro";
                txtLetra1.Text = "s";
                txtLetra2.Text = "z";
                palavraCorreta = "Fósforo";
            }
            if (qtdePalavras == 76)
            {
                txtPalavra.Text = "A dar";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Andar";
            }
            if (qtdePalavras == 77)
            {
                txtPalavra.Text = "Nuve ";
                txtLetra1.Text = "n";
                txtLetra2.Text = "m";
                palavraCorreta = "Nuvem";
            }
            if (qtdePalavras == 78)
            {
                txtPalavra.Text = "Pai ão";
                txtLetra1.Text = "x";
                txtLetra2.Text = "ch";
                palavraCorreta = "Paixão";
            }
            if (qtdePalavras == 79)
            {
                txtPalavra.Text = "A fabeto";
                txtLetra1.Text = "l";
                txtLetra2.Text = "u";
                palavraCorreta = "Alfabeto";
            }
            if (qtdePalavras == 80)
            {
                txtPalavra.Text = "Apare er";
                txtLetra1.Text = "c";
                txtLetra2.Text = "ss";
                palavraCorreta = "Aparecer";
            }
            qtdePalavras += 1;
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}