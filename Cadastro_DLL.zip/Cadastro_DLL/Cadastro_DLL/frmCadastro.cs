﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_DLL
{
    public partial class frmCadastro : Form
    {
        public frmCadastro()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close(); // Fecha este formulário
        }

        private void frmCadastro_Load(object sender, EventArgs e)
        {
            cmbUF.Items.Add("SP");
            cmbUF.Items.Add("MG");
            cmbUF.Items.Add("RJ");
            cmbUF.Items.Add("RS");
            cmbUF.Items.Add("DF");
            cmbUF.Items.Add("PR");
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            btnSalvar.Enabled = false;
            btnNovo.Enabled = true;

            // Limpa o conteúdo das caixas de texto
            txtCodigo.Clear();
            txtNome.Clear();
            txtCidade.Clear();
            cmbUF.SelectedIndex = - 1;
            mskCPF.Clear();
            txtRG.Clear();

            gpbDados.Enabled = false;

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            gpbDados.Enabled = true;
            btnNovo.Enabled = false;
            btnSalvar.Enabled = true;
            txtCodigo.Focus();
        }
    }
}
