﻿namespace Formularios
{
    partial class frmStrings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabStrings = new System.Windows.Forms.TabControl();
            this.tabStrings1 = new System.Windows.Forms.TabPage();
            this.tabStrings2 = new System.Windows.Forms.TabPage();
            this.btnMaiusculas = new System.Windows.Forms.Button();
            this.btnMinusculas = new System.Windows.Forms.Button();
            this.btnTamanhoString = new System.Windows.Forms.Button();
            this.lblTexto = new System.Windows.Forms.Label();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.txtTexto2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblInicio = new System.Windows.Forms.Label();
            this.txtInicio = new System.Windows.Forms.TextBox();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.tabStrings.SuspendLayout();
            this.tabStrings1.SuspendLayout();
            this.tabStrings2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabStrings
            // 
            this.tabStrings.Controls.Add(this.tabStrings1);
            this.tabStrings.Controls.Add(this.tabStrings2);
            this.tabStrings.Location = new System.Drawing.Point(12, 12);
            this.tabStrings.Name = "tabStrings";
            this.tabStrings.SelectedIndex = 0;
            this.tabStrings.Size = new System.Drawing.Size(527, 214);
            this.tabStrings.TabIndex = 0;
            // 
            // tabStrings1
            // 
            this.tabStrings1.Controls.Add(this.txtTexto);
            this.tabStrings1.Controls.Add(this.lblTexto);
            this.tabStrings1.Controls.Add(this.btnTamanhoString);
            this.tabStrings1.Controls.Add(this.btnMinusculas);
            this.tabStrings1.Controls.Add(this.btnMaiusculas);
            this.tabStrings1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabStrings1.Location = new System.Drawing.Point(4, 22);
            this.tabStrings1.Name = "tabStrings1";
            this.tabStrings1.Padding = new System.Windows.Forms.Padding(3);
            this.tabStrings1.Size = new System.Drawing.Size(519, 188);
            this.tabStrings1.TabIndex = 0;
            this.tabStrings1.Text = "Strings1";
            this.tabStrings1.UseVisualStyleBackColor = true;
            // 
            // tabStrings2
            // 
            this.tabStrings2.Controls.Add(this.btnMostrar);
            this.tabStrings2.Controls.Add(this.txtQuantidade);
            this.tabStrings2.Controls.Add(this.txtInicio);
            this.tabStrings2.Controls.Add(this.lblQuantidade);
            this.tabStrings2.Controls.Add(this.txtTexto2);
            this.tabStrings2.Controls.Add(this.lblInicio);
            this.tabStrings2.Controls.Add(this.label1);
            this.tabStrings2.Location = new System.Drawing.Point(4, 22);
            this.tabStrings2.Name = "tabStrings2";
            this.tabStrings2.Padding = new System.Windows.Forms.Padding(3);
            this.tabStrings2.Size = new System.Drawing.Size(519, 188);
            this.tabStrings2.TabIndex = 1;
            this.tabStrings2.Text = "Strings2";
            this.tabStrings2.UseVisualStyleBackColor = true;
            // 
            // btnMaiusculas
            // 
            this.btnMaiusculas.BackColor = System.Drawing.Color.Blue;
            this.btnMaiusculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaiusculas.ForeColor = System.Drawing.Color.White;
            this.btnMaiusculas.Location = new System.Drawing.Point(33, 84);
            this.btnMaiusculas.Name = "btnMaiusculas";
            this.btnMaiusculas.Size = new System.Drawing.Size(131, 75);
            this.btnMaiusculas.TabIndex = 0;
            this.btnMaiusculas.Text = "Converter para maiúsculas";
            this.btnMaiusculas.UseVisualStyleBackColor = false;
            this.btnMaiusculas.Click += new System.EventHandler(this.btnMaiusculas_Click);
            // 
            // btnMinusculas
            // 
            this.btnMinusculas.BackColor = System.Drawing.Color.IndianRed;
            this.btnMinusculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinusculas.ForeColor = System.Drawing.Color.White;
            this.btnMinusculas.Location = new System.Drawing.Point(180, 84);
            this.btnMinusculas.Name = "btnMinusculas";
            this.btnMinusculas.Size = new System.Drawing.Size(131, 75);
            this.btnMinusculas.TabIndex = 0;
            this.btnMinusculas.Text = "Converter para minúsculas";
            this.btnMinusculas.UseVisualStyleBackColor = false;
            this.btnMinusculas.Click += new System.EventHandler(this.btnMinusculas_Click);
            // 
            // btnTamanhoString
            // 
            this.btnTamanhoString.BackColor = System.Drawing.Color.Green;
            this.btnTamanhoString.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTamanhoString.ForeColor = System.Drawing.Color.White;
            this.btnTamanhoString.Location = new System.Drawing.Point(325, 84);
            this.btnTamanhoString.Name = "btnTamanhoString";
            this.btnTamanhoString.Size = new System.Drawing.Size(176, 75);
            this.btnTamanhoString.TabIndex = 0;
            this.btnTamanhoString.Text = "Obtém o tamanho da string";
            this.btnTamanhoString.UseVisualStyleBackColor = false;
            this.btnTamanhoString.Click += new System.EventHandler(this.btnTamanhoString_Click);
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(17, 20);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(110, 18);
            this.lblTexto.TabIndex = 1;
            this.lblTexto.Text = "Digite um texto:";
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(17, 39);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(484, 24);
            this.txtTexto.TabIndex = 2;
            // 
            // txtTexto2
            // 
            this.txtTexto2.Location = new System.Drawing.Point(18, 32);
            this.txtTexto2.Name = "txtTexto2";
            this.txtTexto2.Size = new System.Drawing.Size(484, 20);
            this.txtTexto2.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Digite um texto:";
            // 
            // lblInicio
            // 
            this.lblInicio.AutoSize = true;
            this.lblInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInicio.Location = new System.Drawing.Point(156, 59);
            this.lblInicio.Name = "lblInicio";
            this.lblInicio.Size = new System.Drawing.Size(46, 18);
            this.lblInicio.TabIndex = 3;
            this.lblInicio.Text = "Início:";
            // 
            // txtInicio
            // 
            this.txtInicio.Location = new System.Drawing.Point(159, 80);
            this.txtInicio.Name = "txtInicio";
            this.txtInicio.Size = new System.Drawing.Size(62, 20);
            this.txtInicio.TabIndex = 4;
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidade.Location = new System.Drawing.Point(246, 59);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(87, 18);
            this.lblQuantidade.TabIndex = 3;
            this.lblQuantidade.Text = "Quantidade:";
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(249, 80);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(62, 20);
            this.txtQuantidade.TabIndex = 4;
            // 
            // btnMostrar
            // 
            this.btnMostrar.BackColor = System.Drawing.Color.Navy;
            this.btnMostrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnMostrar.Location = new System.Drawing.Point(192, 121);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(119, 51);
            this.btnMostrar.TabIndex = 5;
            this.btnMostrar.Text = "&Mostrar";
            this.btnMostrar.UseVisualStyleBackColor = false;
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(31, 243);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(79, 18);
            this.lblResultado.TabIndex = 1;
            this.lblResultado.Text = "Resultado:";
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(116, 244);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(393, 20);
            this.txtResultado.TabIndex = 2;
            // 
            // btnVoltar
            // 
            this.btnVoltar.BackColor = System.Drawing.Color.White;
            this.btnVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltar.ForeColor = System.Drawing.Color.Red;
            this.btnVoltar.Image = global::Formularios.Properties.Resources.Sair;
            this.btnVoltar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVoltar.Location = new System.Drawing.Point(229, 272);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(128, 57);
            this.btnVoltar.TabIndex = 3;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVoltar.UseVisualStyleBackColor = false;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // frmStrings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 341);
            this.Controls.Add(this.btnVoltar);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.tabStrings);
            this.Name = "frmStrings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Métodos string";
            this.tabStrings.ResumeLayout(false);
            this.tabStrings1.ResumeLayout(false);
            this.tabStrings1.PerformLayout();
            this.tabStrings2.ResumeLayout(false);
            this.tabStrings2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabStrings;
        private System.Windows.Forms.TabPage tabStrings1;
        private System.Windows.Forms.TabPage tabStrings2;
        private System.Windows.Forms.Button btnTamanhoString;
        private System.Windows.Forms.Button btnMinusculas;
        private System.Windows.Forms.Button btnMaiusculas;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.TextBox txtInicio;
        private System.Windows.Forms.TextBox txtTexto2;
        private System.Windows.Forms.Label lblInicio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnVoltar;
    }
}