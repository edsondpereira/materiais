﻿namespace Formularios
{
    partial class frmStrings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabStrings = new System.Windows.Forms.TabControl();
            this.tabStrings1 = new System.Windows.Forms.TabPage();
            this.tabStrings2 = new System.Windows.Forms.TabPage();
            this.tabStrings.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabStrings
            // 
            this.tabStrings.Controls.Add(this.tabStrings1);
            this.tabStrings.Controls.Add(this.tabStrings2);
            this.tabStrings.Location = new System.Drawing.Point(12, 12);
            this.tabStrings.Name = "tabStrings";
            this.tabStrings.SelectedIndex = 0;
            this.tabStrings.Size = new System.Drawing.Size(311, 154);
            this.tabStrings.TabIndex = 0;
            // 
            // tabStrings1
            // 
            this.tabStrings1.Location = new System.Drawing.Point(4, 22);
            this.tabStrings1.Name = "tabStrings1";
            this.tabStrings1.Padding = new System.Windows.Forms.Padding(3);
            this.tabStrings1.Size = new System.Drawing.Size(303, 128);
            this.tabStrings1.TabIndex = 0;
            this.tabStrings1.Text = "Strings1";
            this.tabStrings1.UseVisualStyleBackColor = true;
            // 
            // tabStrings2
            // 
            this.tabStrings2.Location = new System.Drawing.Point(4, 22);
            this.tabStrings2.Name = "tabStrings2";
            this.tabStrings2.Padding = new System.Windows.Forms.Padding(3);
            this.tabStrings2.Size = new System.Drawing.Size(303, 128);
            this.tabStrings2.TabIndex = 1;
            this.tabStrings2.Text = "Strings2";
            this.tabStrings2.UseVisualStyleBackColor = true;
            // 
            // frmStrings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabStrings);
            this.Name = "frmStrings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Métodos string";
            this.tabStrings.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabStrings;
        private System.Windows.Forms.TabPage tabStrings1;
        private System.Windows.Forms.TabPage tabStrings2;
    }
}