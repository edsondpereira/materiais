﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public partial class frmStrings : Form
    {
        public frmStrings()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Dispose(); // Fecha este formulário
        }

        private void btnMaiusculas_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtTexto.Text.ToUpper();
        }

        private void btnMinusculas_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtResultado.Text.ToLower();
        }

        private void btnTamanhoString_Click(object sender, EventArgs e)
        {            
            if (txtTexto.Text.Length > 0)
            {
                txtResultado.Text = string.Format("O texto digitado tem {0} caracteres!", txtTexto.Text.Length);
            }
            else
            {
                txtResultado.Clear();
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            if (txtInicio.Text.Length == 0)
            {
                MessageBox.Show("Por favor... informe onde inicia a string!");
                txtInicio.Focus();
                return;
            }

            if (txtQuantidade.Text.Length == 0)
            {
                MessageBox.Show("Por favor... informe quantos caracteres você deseja exibir!");
                txtQuantidade.Focus();
                return;
            }

            int inicio = Convert.ToInt16(txtInicio.Text);
            int quantidade = Convert.ToInt16(txtQuantidade.Text);

            txtResultado.Text = txtTexto2.Text.Substring(inicio, quantidade);
        }
    }
}
