﻿namespace Formularios
{
    partial class frmComandos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblDataMSK = new System.Windows.Forms.Label();
            this.mskData = new System.Windows.Forms.MaskedTextBox();
            this.mskHora = new System.Windows.Forms.MaskedTextBox();
            this.lblHora = new System.Windows.Forms.Label();
            this.lblHoraPanel = new System.Windows.Forms.Label();
            this.pnlHora = new System.Windows.Forms.Panel();
            this.lblHoraTimer = new System.Windows.Forms.Label();
            this.lblDataDTP = new System.Windows.Forms.Label();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.lblCalData = new System.Windows.Forms.Label();
            this.mthCalendario = new System.Windows.Forms.MonthCalendar();
            this.tmrHora = new System.Windows.Forms.Timer(this.components);
            this.pnlHora.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDataMSK
            // 
            this.lblDataMSK.AutoSize = true;
            this.lblDataMSK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataMSK.Location = new System.Drawing.Point(13, 21);
            this.lblDataMSK.Name = "lblDataMSK";
            this.lblDataMSK.Size = new System.Drawing.Size(48, 20);
            this.lblDataMSK.TabIndex = 0;
            this.lblDataMSK.Text = "Data:";
            // 
            // mskData
            // 
            this.mskData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskData.Location = new System.Drawing.Point(15, 41);
            this.mskData.Mask = "##/##/####";
            this.mskData.Name = "mskData";
            this.mskData.Size = new System.Drawing.Size(95, 26);
            this.mskData.TabIndex = 1;
            // 
            // mskHora
            // 
            this.mskHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskHora.Location = new System.Drawing.Point(132, 41);
            this.mskHora.Mask = "##:##";
            this.mskHora.Name = "mskHora";
            this.mskHora.Size = new System.Drawing.Size(62, 26);
            this.mskHora.TabIndex = 3;
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.Location = new System.Drawing.Point(130, 21);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(48, 20);
            this.lblHora.TabIndex = 2;
            this.lblHora.Text = "Hora:";
            // 
            // lblHoraPanel
            // 
            this.lblHoraPanel.AutoSize = true;
            this.lblHoraPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoraPanel.Location = new System.Drawing.Point(225, 21);
            this.lblHoraPanel.Name = "lblHoraPanel";
            this.lblHoraPanel.Size = new System.Drawing.Size(48, 20);
            this.lblHoraPanel.TabIndex = 2;
            this.lblHoraPanel.Text = "Hora:";
            // 
            // pnlHora
            // 
            this.pnlHora.BackColor = System.Drawing.Color.White;
            this.pnlHora.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlHora.Controls.Add(this.lblHoraTimer);
            this.pnlHora.Location = new System.Drawing.Point(229, 41);
            this.pnlHora.Name = "pnlHora";
            this.pnlHora.Size = new System.Drawing.Size(81, 26);
            this.pnlHora.TabIndex = 4;
            // 
            // lblHoraTimer
            // 
            this.lblHoraTimer.AutoSize = true;
            this.lblHoraTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoraTimer.Location = new System.Drawing.Point(3, 1);
            this.lblHoraTimer.Name = "lblHoraTimer";
            this.lblHoraTimer.Size = new System.Drawing.Size(71, 20);
            this.lblHoraTimer.TabIndex = 0;
            this.lblHoraTimer.Text = "00:00:00";
            // 
            // lblDataDTP
            // 
            this.lblDataDTP.AutoSize = true;
            this.lblDataDTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataDTP.Location = new System.Drawing.Point(12, 98);
            this.lblDataDTP.Name = "lblDataDTP";
            this.lblDataDTP.Size = new System.Drawing.Size(48, 20);
            this.lblDataDTP.TabIndex = 0;
            this.lblDataDTP.Text = "Data:";
            // 
            // dtpData
            // 
            this.dtpData.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpData.Location = new System.Drawing.Point(12, 121);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(98, 20);
            this.dtpData.TabIndex = 5;
            // 
            // lblCalData
            // 
            this.lblCalData.AutoSize = true;
            this.lblCalData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCalData.Location = new System.Drawing.Point(128, 98);
            this.lblCalData.Name = "lblCalData";
            this.lblCalData.Size = new System.Drawing.Size(89, 20);
            this.lblCalData.TabIndex = 0;
            this.lblCalData.Text = "Calendário:";
            // 
            // mthCalendario
            // 
            this.mthCalendario.Location = new System.Drawing.Point(126, 121);
            this.mthCalendario.Name = "mthCalendario";
            this.mthCalendario.TabIndex = 6;
            // 
            // tmrHora
            // 
            this.tmrHora.Interval = 1000;
            this.tmrHora.Tick += new System.EventHandler(this.tmrHora_Tick);
            // 
            // frmComandos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 312);
            this.Controls.Add(this.mthCalendario);
            this.Controls.Add(this.dtpData);
            this.Controls.Add(this.pnlHora);
            this.Controls.Add(this.mskHora);
            this.Controls.Add(this.lblHoraPanel);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.mskData);
            this.Controls.Add(this.lblCalData);
            this.Controls.Add(this.lblDataDTP);
            this.Controls.Add(this.lblDataMSK);
            this.Name = "frmComandos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comandos de Data e Hora";
            this.Load += new System.EventHandler(this.frmComandos_Load);
            this.pnlHora.ResumeLayout(false);
            this.pnlHora.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDataMSK;
        private System.Windows.Forms.MaskedTextBox mskData;
        private System.Windows.Forms.MaskedTextBox mskHora;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblHoraPanel;
        private System.Windows.Forms.Panel pnlHora;
        private System.Windows.Forms.Label lblHoraTimer;
        private System.Windows.Forms.Label lblDataDTP;
        private System.Windows.Forms.DateTimePicker dtpData;
        private System.Windows.Forms.Label lblCalData;
        private System.Windows.Forms.MonthCalendar mthCalendario;
        private System.Windows.Forms.Timer tmrHora;
    }
}