﻿namespace Formularios
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mmsMenu = new System.Windows.Forms.MenuStrip();
            this.mnuArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStrings = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemMetodos = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDataHora = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemComandosDH = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAjuda = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemSobre = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuJanela = new System.Windows.Forms.ToolStripMenuItem();
            this.organizarVerticalmenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemHorizontalmente = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemCascata = new System.Windows.Forms.ToolStripMenuItem();
            this.mmsMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // mmsMenu
            // 
            this.mmsMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuArquivo,
            this.mnuStrings,
            this.mnuDataHora,
            this.mnuAjuda,
            this.mnuJanela});
            this.mmsMenu.Location = new System.Drawing.Point(0, 0);
            this.mmsMenu.Name = "mmsMenu";
            this.mmsMenu.Size = new System.Drawing.Size(800, 24);
            this.mmsMenu.TabIndex = 0;
            this.mmsMenu.Text = "menuStrip1";
            // 
            // mnuArquivo
            // 
            this.mnuArquivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemArquivo});
            this.mnuArquivo.Name = "mnuArquivo";
            this.mnuArquivo.Size = new System.Drawing.Size(61, 20);
            this.mnuArquivo.Text = "&Arquivo";
            // 
            // mnuItemArquivo
            // 
            this.mnuItemArquivo.Name = "mnuItemArquivo";
            this.mnuItemArquivo.Size = new System.Drawing.Size(180, 22);
            this.mnuItemArquivo.Text = "Sai&r";
            this.mnuItemArquivo.Click += new System.EventHandler(this.mnuItemArquivo_Click);
            // 
            // mnuStrings
            // 
            this.mnuStrings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemMetodos});
            this.mnuStrings.Name = "mnuStrings";
            this.mnuStrings.Size = new System.Drawing.Size(100, 20);
            this.mnuStrings.Text = "&Métodos String";
            // 
            // mnuItemMetodos
            // 
            this.mnuItemMetodos.Name = "mnuItemMetodos";
            this.mnuItemMetodos.Size = new System.Drawing.Size(180, 22);
            this.mnuItemMetodos.Text = "&Métodos ";
            this.mnuItemMetodos.Click += new System.EventHandler(this.mnuItemMetodos_Click);
            // 
            // mnuDataHora
            // 
            this.mnuDataHora.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemComandosDH});
            this.mnuDataHora.Name = "mnuDataHora";
            this.mnuDataHora.Size = new System.Drawing.Size(81, 20);
            this.mnuDataHora.Text = "&Data e Hora";
            // 
            // mnuItemComandosDH
            // 
            this.mnuItemComandosDH.Name = "mnuItemComandosDH";
            this.mnuItemComandosDH.Size = new System.Drawing.Size(180, 22);
            this.mnuItemComandosDH.Text = "C&omandos";
            this.mnuItemComandosDH.Click += new System.EventHandler(this.mnuItemComandosDH_Click);
            // 
            // mnuAjuda
            // 
            this.mnuAjuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemSobre});
            this.mnuAjuda.Name = "mnuAjuda";
            this.mnuAjuda.Size = new System.Drawing.Size(50, 20);
            this.mnuAjuda.Text = "Aj&uda";
            // 
            // mnuItemSobre
            // 
            this.mnuItemSobre.Name = "mnuItemSobre";
            this.mnuItemSobre.Size = new System.Drawing.Size(104, 22);
            this.mnuItemSobre.Text = "S&obre";
            // 
            // mnuJanela
            // 
            this.mnuJanela.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.organizarVerticalmenteToolStripMenuItem,
            this.mnuItemHorizontalmente,
            this.mnuItemCascata});
            this.mnuJanela.Name = "mnuJanela";
            this.mnuJanela.Size = new System.Drawing.Size(51, 20);
            this.mnuJanela.Text = "&Janela";
            // 
            // organizarVerticalmenteToolStripMenuItem
            // 
            this.organizarVerticalmenteToolStripMenuItem.Name = "organizarVerticalmenteToolStripMenuItem";
            this.organizarVerticalmenteToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.organizarVerticalmenteToolStripMenuItem.Text = "Organizar &Verticalmente";
            // 
            // mnuItemHorizontalmente
            // 
            this.mnuItemHorizontalmente.Name = "mnuItemHorizontalmente";
            this.mnuItemHorizontalmente.Size = new System.Drawing.Size(217, 22);
            this.mnuItemHorizontalmente.Text = "Organizar &Horizontalmente";
            // 
            // mnuItemCascata
            // 
            this.mnuItemCascata.Name = "mnuItemCascata";
            this.mnuItemCascata.Size = new System.Drawing.Size(217, 22);
            this.mnuItemCascata.Text = "Cascata";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mmsMenu);
            this.MainMenuStrip = this.mmsMenu;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manipulando Strings - Data e Hora";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.mmsMenu.ResumeLayout(false);
            this.mmsMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mmsMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuArquivo;
        private System.Windows.Forms.ToolStripMenuItem mnuItemArquivo;
        private System.Windows.Forms.ToolStripMenuItem mnuStrings;
        private System.Windows.Forms.ToolStripMenuItem mnuItemMetodos;
        private System.Windows.Forms.ToolStripMenuItem mnuDataHora;
        private System.Windows.Forms.ToolStripMenuItem mnuItemComandosDH;
        private System.Windows.Forms.ToolStripMenuItem mnuAjuda;
        private System.Windows.Forms.ToolStripMenuItem mnuItemSobre;
        private System.Windows.Forms.ToolStripMenuItem mnuJanela;
        private System.Windows.Forms.ToolStripMenuItem organizarVerticalmenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuItemHorizontalmente;
        private System.Windows.Forms.ToolStripMenuItem mnuItemCascata;
    }
}

